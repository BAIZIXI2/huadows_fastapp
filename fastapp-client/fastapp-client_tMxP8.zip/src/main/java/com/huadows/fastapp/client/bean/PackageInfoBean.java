package com.huadows.fastapp.client.bean;

public class PackageInfoBean {
    public String packageName;
    public String versionName;
    public int versionCode;
    public String applicationLabel;
    public long totalSizeBytes;
    public long appSize;
    public long dataSize;
    public long cacheSize;
}