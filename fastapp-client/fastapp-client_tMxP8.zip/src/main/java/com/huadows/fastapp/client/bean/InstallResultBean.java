package com.huadows.fastapp.client.bean;

public class InstallResultBean {
    public String status;
    public String message;
    public String packageName;
}