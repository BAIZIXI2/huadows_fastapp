package com.huadows.fastapp.client.bean;

public class AppInfoBean {
    public String name;
    public String packageName;
    public String versionName;
    public int versionCode;
}