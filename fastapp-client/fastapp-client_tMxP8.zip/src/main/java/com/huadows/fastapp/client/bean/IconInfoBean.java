package com.huadows.fastapp.client.bean;

public class IconInfoBean {
    public String icon; // Base64 encoded icon
    public String error;
}