package com.huadows.fastapp.client.bean;

public class ApiResponse {
    public String status;
    public String message;
}